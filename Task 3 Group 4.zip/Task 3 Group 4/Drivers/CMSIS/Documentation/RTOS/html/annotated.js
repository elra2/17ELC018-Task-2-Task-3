var annotated =
[
    [ "os_mailQ", "group___c_m_s_i_s___r_t_o_s___definitions.html#structos__mail_q", null ],
    [ "osEvent", "group___c_m_s_i_s___r_t_o_s___definitions.html#structos_event", "group___c_m_s_i_s___r_t_o_s___definitions" ],
    [ "osMailQDef_t", "structos_mail_q_def__t.html", "structos_mail_q_def__t" ],
    [ "osMessageQDef_t", "structos_message_q_def__t.html", "structos_message_q_def__t" ],
    [ "osMutexDef_t", "structos_mutex_def__t.html", "structos_mutex_def__t" ],
    [ "osPoolDef_t", "structos_pool_def__t.html", "structos_pool_def__t" ],
    [ "osSemaphoreDef_t", "structos_semaphore_def__t.html", "structos_semaphore_def__t" ],
    [ "osThreadDef_t", "structos_thread_def__t.html", "structos_thread_def__t" ],
    [ "osTimerDef_t", "structos_timer_def__t.html", "structos_timer_def__t" ]
];